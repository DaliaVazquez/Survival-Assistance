prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.6'
,p_default_workspace_id=>7335414224096019
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECT'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(17233854439707893)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Zombie'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.safe{',
'    background-color: green;',
'}',
'',
'.alert{',
'    background-color: rgb(148, 148, 3);',
'}',
'',
'.danger{',
'    background-color: red;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'DALIA'
,p_last_upd_yyyymmddhh24miss=>'20221118222703'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16811928789658245)
,p_plug_name=>'Seguro'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA'
,p_plug_template=>wwv_flow_imp.id(17082766168707783)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select zl2.ID,',
'       zl2.NOMBRE,',
'       zl2.DIRECCION,',
'       zl2.ESTADO,',
'       zl2.suministros,',
'       za.km,',
'       za.id id_camino',
'  from ZOMBIE_LUGAR zl',
'  join zombie_arista za',
'  on zl.id = za.l1',
'  join zombie_LUGAR zl2',
'  on zl2.id = za.l2',
'  where zl2.estado =''Seguro''',
'  and zl.nombre = :P1_ID_LUGAR',
'  order by za.km'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_plug_header=>'Refugios seguros'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(18719487375086407)
,p_region_id=>wwv_flow_imp.id(16811928789658245)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&NOMBRE.  <br>',
'<sup>A &KM. Km </sup><br>',
'<sup>Direccion: &DIRECCION. </sup>'))
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'SUMINISTROS'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'ESTADO'
,p_badge_css_classes=>'safe'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(16965296925690144)
,p_card_id=>wwv_flow_imp.id(18719487375086407)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:CR,18:P18_ID:&ID_CAMINO.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18719563164086408)
,p_plug_name=>'Peligro'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17082766168707783)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select zl2.ID,',
'       zl2.NOMBRE,',
'       zl2.DIRECCION,',
'       zl2.ESTADO,',
'       zl2.suministros,',
'       za.km,',
'       za.id id_camino',
'  from ZOMBIE_LUGAR zl',
'  join zombie_arista za',
'  on zl.id = za.l1',
'  join zombie_LUGAR zl2',
'  on zl2.id = za.l2',
'  where zl2.estado =''Peligro''',
'  and zl.nombre = :P1_ID_LUGAR',
'  order by za.km'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_plug_header=>'Refugios en peligro'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(18719692243086409)
,p_region_id=>wwv_flow_imp.id(18719563164086408)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&NOMBRE. <br>',
'<sup>A &KM. Km </sup><br>',
'<sup>Direccion: &DIRECCION. </sup>'))
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'SUMINISTROS'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'ESTADO'
,p_badge_css_classes=>'danger'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(19544787230359804)
,p_card_id=>wwv_flow_imp.id(18719692243086409)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:CR,18:P18_ID:&ID_CAMINO.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18719723820086410)
,p_plug_name=>'Alerta'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17082766168707783)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select zl2.ID,',
'       zl2.NOMBRE,',
'       zl2.DIRECCION,',
'       zl2.ESTADO,',
'       zl2.suministros,',
'       za.km,',
'       za.id id_camino',
'  from ZOMBIE_LUGAR zl',
'  join zombie_arista za',
'  on zl.id = za.l1',
'  join zombie_LUGAR zl2',
'  on zl2.id = za.l2',
'  where zl2.estado =''Alerta''',
'  and zl.nombre = :P1_ID_LUGAR',
'  order by za.km'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_plug_header=>'Refugios en alerta'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(18719857310086411)
,p_region_id=>wwv_flow_imp.id(18719723820086410)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'&NOMBRE. <br>',
'<sup>A &KM. Km </sup><br>',
'<sup>Direccion: &DIRECCION. </sup>'))
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'SUMINISTROS'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'ESTADO'
,p_badge_css_classes=>'alert'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(19544625401359803)
,p_card_id=>wwv_flow_imp.id(18719857310086411)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:CR,18:P18_ID:&ID_CAMINO.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18722670832086439)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(17145890848707825)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'Buscar en refugios:'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18720477129086417)
,p_plug_name=>'Peligrosos'
,p_parent_plug_id=>wwv_flow_imp.id(18722670832086439)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17077090965707781)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(18719563164086408)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18722036461086433)
,p_plug_name=>'Alerta'
,p_parent_plug_id=>wwv_flow_imp.id(18722670832086439)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17077090965707781)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(18719723820086410)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18722324036086436)
,p_plug_name=>'Seguros'
,p_parent_plug_id=>wwv_flow_imp.id(18722670832086439)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17077090965707781)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(16811928789658245)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_06=>'N'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18720010642086413)
,p_button_sequence=>20
,p_button_name=>'Buscar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(17208946208707862)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18719922474086412)
,p_name=>'P1_ID_LUGAR'
,p_item_sequence=>10
,p_prompt=>unistr('\00BFD\00F3nde estas?')
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_named_lov=>'ZOMBIE_LUGAR.NOMBRE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(17206429629707859)
,p_item_template_options=>'#DEFAULT#:margin-bottom-lg'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18720720412086420)
,p_name=>'P1_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18720477129086417)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18722193550086434)
,p_name=>'P1_SEARCH_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18722036461086433)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18722240037086435)
,p_name=>'P1_SEARCH_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18722036461086433)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18722461016086437)
,p_name=>'P1_SEARCH_1_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18722324036086436)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18722595578086438)
,p_name=>'P1_SEARCH_2_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18722324036086436)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(18720158297086414)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(18720010642086413)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(18720358531086416)
,p_event_id=>wwv_flow_imp.id(18720158297086414)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
