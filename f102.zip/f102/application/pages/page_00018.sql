prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.6'
,p_default_workspace_id=>7335414224096019
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PROJECT'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_user_interface_id=>wwv_flow_imp.id(17233854439707893)
,p_name=>'Detalles'
,p_alias=>'DETALLES'
,p_page_mode=>'MODAL'
,p_step_title=>'Detalles'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.Seguro{',
'    background-color: green;',
'}',
'',
'.Alerta{',
'    background-color: rgb(148, 148, 3);',
'}',
'',
'.Peligro{',
'    background-color: red;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'DALIA'
,p_last_upd_yyyymmddhh24miss=>'20221118222207'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16965307457690145)
,p_plug_name=>'Desde'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17082766168707783)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select zl.ID,',
'       zl.NOMBRE,',
'       zl.DIRECCION,',
'       zl.ESTADO,',
'       zl.SUMINISTROS',
'  from ZOMBIE_LUGAR zl',
'  join zombie_arista za',
'  on za.l1 = zl.id',
'  where za.id = :P18_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(16965442626690146)
,p_region_id=>wwv_flow_imp.id(16965307457690145)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>'Desde: &NOMBRE.'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DIRECCION'
,p_body_adv_formatting=>true
,p_body_html_expr=>'Tiene: &SUMINISTROS.'
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'ESTADO'
,p_badge_css_classes=>'&ESTADO.'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16965537513690147)
,p_plug_name=>'camino'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17082766168707783)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       L1,',
'       L2,',
'       KM,',
'       NOTAS,',
'       ESTADO',
'  from ZOMBIE_ARISTA',
'  where id = :P18_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(16965691067690148)
,p_region_id=>wwv_flow_imp.id(16965537513690147)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<div>A &KM. Km</div>'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'<div>Estado del camino: </div>'
,p_body_adv_formatting=>false
,p_body_column_name=>'NOTAS'
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'ESTADO'
,p_badge_css_classes=>'&ESTADO.'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(19544560994359802)
,p_card_id=>wwv_flow_imp.id(16965691067690148)
,p_action_type=>'BUTTON'
,p_position=>'PRIMARY'
,p_display_sequence=>10
,p_label=>'Editar'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:CR,20:P20_ID:&ID.'
,p_button_display_type=>'TEXT'
,p_is_hot=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16965711064690149)
,p_plug_name=>'hacia'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17082766168707783)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select zl.ID,',
'       zl.NOMBRE,',
'       zl.DIRECCION,',
'       zl.ESTADO,',
'       zl.SUMINISTROS',
'  from ZOMBIE_LUGAR zl',
'  join zombie_arista za',
'  on za.l2 = zl.id',
'  where za.id = :P18_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(16965844582690150)
,p_region_id=>wwv_flow_imp.id(16965711064690149)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>'Hacia: &NOMBRE.'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DIRECCION'
,p_body_adv_formatting=>true
,p_body_html_expr=>'Tiene: &SUMINISTROS.'
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'ESTADO'
,p_badge_css_classes=>'&ESTADO.'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16965109683690143)
,p_name=>'P18_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
